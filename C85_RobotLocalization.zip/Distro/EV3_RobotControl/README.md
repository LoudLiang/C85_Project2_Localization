# EV3_RobotControl
Lego EV3 Robot Control API using Bluetooth

This repo contains a bare-bones communication interface for Lego EV3 robots over bluetooth.
The provided API allows for motor control and sensor polling.

For use in the CSC C85 Embedded Systems course at UTSC

Developed by:

Lioudmila Tishkina

Francisco Estrada
