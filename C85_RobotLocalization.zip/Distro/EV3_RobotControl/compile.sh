g++ btcomm_test.c btcomm.c -lbluetooth
